package com.example.student.enumeration;

public enum SubjectName {
	
	MATHEMATIKA,
	JAVA,
	PHISICS,
	ALGEBRA,
	ALGORITHMS

}
