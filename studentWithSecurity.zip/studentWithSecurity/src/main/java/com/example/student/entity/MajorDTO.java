package com.example.student.entity;

import javax.persistence.Entity;

public interface MajorDTO {
	
	Long getId();
	String getName();
	
	

}
